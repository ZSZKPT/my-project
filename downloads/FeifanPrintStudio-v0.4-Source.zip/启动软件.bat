@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r print_studio\requirements.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m print_studio.main
if errorlevel 1 goto failed
exit /b 0
:failed
echo 启动失败，请安装 Python 3.12 并检查以上错误信息。
pause
exit /b 1
